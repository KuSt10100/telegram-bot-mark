# Telegram Bot Mark
Це простий Telegram-бот, який відповідає на повідомлення.