# Telegram Бот Юлі

## Як запустити:

1. Встановити залежності:
   pip install aiogram

2. Запустити:
   python main.py

## Що він робить:
- Відповідає на /start
- Надсилає посилання на Telegram і TikTok