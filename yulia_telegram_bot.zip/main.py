import asyncio
from aiogram import Bot, Dispatcher, types

API_TOKEN = "8098099076:AAHkw1kj2NCzxhjVXvV1PI0V4bsARBgbn40"

bot = Bot(token=API_TOKEN)
dp = Dispatcher()

@dp.message()
async def handle_all_messages(message: types.Message):
    if message.text == "/start":
        await message.answer("Привіт! Це бойовий бот Юлі. Переходь на наш TikTok або в Telegram-групу:\n\nhttps://t.me/KuSt_Y\nhttps://www.tiktok.com/@kust_y")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())